//
//  Donor_HomeTests.swift
//  Donor HomeTests
//
//  Created by Jxu on 21/12/2025.
//

import Testing
@testable import Donor_Home

struct Donor_HomeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
